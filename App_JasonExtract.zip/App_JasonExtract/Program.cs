﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace jasonExtract

{
    class Program
    {
        private static readonly HttpClient client = new HttpClient();
        private
        const string countriesEndpoint = "https://restcountries.eu/rest/v2/all";

        static void Main(string[] args)
        {
            Country[] countries = GetCountries(countriesEndpoint).GetAwaiter().GetResult();
            List<Country> countriesList = new List<Country>(countries);

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Palota Interview: Country Facts");
            Console.WriteLine();
            Console.ResetColor();

            Random rnd = new Random(); // random to populate fake answer - you can remove this once you use real values

            //TODO use data operations and data structures to optimally find the correct value (N.B. be aware of null values)

            /*
             * HINT: Sort the list in descending order to find South Africa's place in terms of gini coefficients
             * `Country.Gini` is the relevant field to use here           
             */
            var countryList = countriesList.OrderByDescending(w => w.Gini).ToList();
            var southAfricanGiniPlace = countryList.FindIndex(S => S.Name.Equals("South Africa"));
            Console.WriteLine($"1. South Africa's Gini coefficient is the {GetOrdinal(southAfricanGiniPlace)} highest");


            /*
             * HINT: Sort the list in ascending order or just find the Country with the minimum gini coeficient          
             * use `Country.Gini` for the ordering then return the relevant country's name `Country.Name`
             */
            string lowestGiniCountry = countriesList.OrderBy(w => w.Gini).FirstOrDefault().Name;
            Console.WriteLine($"2. {lowestGiniCountry} has the lowest Gini Coefficient");


            /*
             * HINT: Group by regions (`Country.Region`), then count the number of unique timezones that the countries in each region span
             * Once you have done the grouping, find the group `Region` with the most timezones and return it's name and the number of unique timezones found          
             */
            var timezoneresult = (from c in countryList
                                  select new
                                  {
                                      count = c.Timezones.Count(),
                                      name = c.Name,
                                  }).OrderByDescending(w => w.count).FirstOrDefault();


            int amountOfTimezonesInRegion = rnd.Next(1, 10); // Use correct value
            Console.WriteLine($"3. {timezoneresult.name} is the region that spans most timezones at {timezoneresult.count} timezones");


            /*
             * HINT: Count occurances of each currency in all countries (check `Country.Currencies`)
             * Find the name of the currency with most occurances and return it's name (`Currency.Name`) also return the number of occurances found for that currency          
             */
            var currencyList = new List<Currency>();
            countriesList.ForEach(l => currencyList.Add(new Currency()
            {
                Code = l.Currencies[0].Code,
                Name = l.Currencies[0].Name,
                Symbol = l.Currencies[0].Symbol
            }));

            var mostPopularCurrency = from c in currencyList
                                      group c by c.Name into g
                                      orderby g.Count() descending
                                      select new
                                      {
                                          count = g.Count(),
                                          name = g.First().Name,
                                      };

            // Use correct value
            int numCountriesUsedByCurrency = rnd.Next(1, 10); // Use correct value
            Console.WriteLine($"4. {mostPopularCurrency.FirstOrDefault().name} is the most popular currency and is used in {mostPopularCurrency.FirstOrDefault().count} countries");



            /*
             * HINT: Count the number of occurances of each language (`Country.Languages`) and sort then in descending occurances count (i.e. most populat first)
             * Once done return the names of the top three languages (`Language.Name`)
             */
            var languageList = new List<Language>();
            countryList.ForEach(l => languageList.Add(new Language()
            {
                Iso6391 = l.Languages[0].Iso6391,
                Iso6392 = l.Languages[0].Iso6392,
                Name = l.Languages[0].Name,
                NativeName = l.Languages[0].NativeName
            }));


            var mostPopularLanguages = (from c in languageList
                                        group c by c.Name into g
                                        orderby g.Count() descending
                                        select new
                                        {
                                            count = g.Count(),
                                            name = g.First().Name,
                                        }).ToArray();

            Console.WriteLine($"5. The top three popular languages are {mostPopularLanguages[0].name}, {mostPopularLanguages[1].name} and {mostPopularLanguages[2].name}");

            /*
             * HINT: Each country has an array of Bordering countries `Country.Borders`, The array has a list of alpha3 codes of each bordering country `Country.alpha3Code`
             * Sum up the population of each country (`Country.Population`) along with all of its bordering countries's population. Sort this list according to the combined population descending
             * Find the country with the highest combined (with bordering countries) population the return that country's name (`Country.Name`), the number of it's Bordering countries (`Country.Borders.length`) and the combined population
             * Be wary of null values           
             */

            long total_countryopopulation = 0;
            int numberofbrodercountry = 0;
            var resultlist = new List<dynamic>();
            foreach (var result in countryList)
            {
                total_countryopopulation = result.Population;
                foreach (var res in result.Borders)
                {
                    total_countryopopulation += countryList.Where(w => w.Alpha3Code.Equals(res.ToString())).FirstOrDefault().Population;
                    ++numberofbrodercountry;
                }
                resultlist.Add(new
                {
                    countryname = result.Name,
                    populationcount = total_countryopopulation,
                    numberofbordercountry = numberofbrodercountry
                });
                numberofbrodercountry = 0;
                total_countryopopulation = 0;
            }
            var numberOfBorderingCountries = resultlist.OrderByDescending(w => w.populationcount).FirstOrDefault();
            Console.WriteLine($"6. {numberOfBorderingCountries.countryname} and it's {numberOfBorderingCountries.numberofbordercountry} bordering countries has the highest combined population of {numberOfBorderingCountries.populationcount}");

            /*
             * HINT: Population density is calculated as (population size)/area, i.e. `Country.Population/Country.Area`
             * Calculate the population density of each country and sort by that value to find the lowest density
             * Return the name of that country (`Country.Name`) and its calculated density.
             * Be wary of null values when doing calculations           
             */


            var countrypopdensitydetails = (from c in countryList
                                            select new
                                            {

                                                density = c.Population / c.Area,
                                                countryname = c.Name
                                            }).Where(w => w.density != null);

            var lowcountrydensitydetials = countrypopdensitydetails.OrderBy(w => w.density).FirstOrDefault();

            Console.WriteLine($"7. {lowcountrydensitydetials.countryname} has the lowest population density of {lowcountrydensitydetials.density}");

            /*
             * HINT: Population density is calculated as (population size)/area, i.e. `Country.Population/Country.Area`
             * Calculate the population density of each country and sort by that value to find the highest density
             * Return the name of that country (`Country.Name`) and its calculated density.
             * Be wary of any null values when doing calculations. Consider reusing work from above related question           
             */
            var highcountrydensitydetials = countrypopdensitydetails.OrderByDescending(w => w.density).FirstOrDefault();
            Console.WriteLine($"8. {highcountrydensitydetials.countryname} has the highest population density of {highcountrydensitydetials.density}");

            /*
             * HINT: Group by subregion `Country.Subregion` and sum up the area (`Country.Area`) of all countries per subregion
             * Sort the subregions by the combined area to find the maximum (or just find the maximum)
             * Return the name of the subregion
             * Be wary of any null values when summing up the area           
             */


            var largestAreaSubregiondetails = countriesList.GroupBy(x => x.Subregion)
             .Select(x => new {
                 subregion = x.Key,
                 area = x.Sum(w => w.Area)
             }).OrderByDescending(w => w.area).FirstOrDefault();
            Console.WriteLine($"9. {largestAreaSubregiondetails.subregion} is the subregion that covers the most area");

            /*
             * HINT: Group by regional blocks (`Country.RegionalBlocks`). For each regional block, average out the gini coefficient (`Country.Gini`) of all member countries
             * Sort the regional blocks by the average country gini coefficient to find the lowest (or find the lowest without sorting)
             * Return the name of the regional block (`RegionalBloc.Name`) along with the calculated average gini coefficient
             */

            List<dynamic> lowestregionalblockginilist = new List<dynamic>();
            foreach (var temp in countriesList)
            {
                foreach (var obj in temp.RegionalBlocs)
                {
                    lowestregionalblockginilist.Add(new
                    {
                        regionalblock = obj.Name,
                        countryname = temp.Name,
                        gini = temp.Gini
                    });
                }
            }

            var lowestRegionalBlockGini = lowestregionalblockginilist.Where(w => w.gini != null).GroupBy(x => new {
                x.regionalblock,
                x.countryname
            })
             .Select(x => new {
                 subregion = x.Key,
                 avg = x.Average(w => Convert.ToInt32(w.gini))
             }).OrderBy(w => w.avg).FirstOrDefault();

            Console.WriteLine($"10. {lowestRegionalBlockGini.subregion.regionalblock} is the regional block with the lowest average Gini coefficient of {lowestRegionalBlockGini.avg}");
            Console.ReadLine();
        }

        /// <summary>
        /// Gets the countries from a specified endpiny
        /// </summary>
        /// <returns>The countries.</returns>
        /// <param name="path">Path endpoint for the API.</param>
        static async Task<Country[]> GetCountries(string path)
        {
            Country[] countries = null;
            //TODO get data from endpoint and convert it to a typed array using Country.FromJson
            //HttpResponseMessage response = await client.GetAsync(path);

            using (var response = client.GetAsync(path).Result)
            {
                if (response.IsSuccessStatusCode)
                {
                    var customerJsonString = await response.Content.ReadAsStringAsync();
                    countries = Country.FromJson(customerJsonString);
                    //var cust = JsonConvert.DeserializeObject<Response>(customerJsonString);
                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
                }
            }
            return countries;
        }

        /// <summary>
        /// Gets the ordinal value of a number (e.g. 1 to 1st)
        /// </summary>
        /// <returns>The ordinal.</returns>
        /// <param name="num">Number.</param>
        public static string GetOrdinal(int num)
        {
            if (num <= 0) return num.ToString();

            switch (num % 100)
            {
                case 11:
                case 12:
                case 13:
                    return num + "th";
            }

            switch (num % 10)
            {
                case 1:
                    return num + "st";
                case 2:
                    return num + "nd";
                case 3:
                    return num + "rd";
                default:
                    return num + "th";
            }

        }
    }
}